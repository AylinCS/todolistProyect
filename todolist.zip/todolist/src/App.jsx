import React, {useEffect, useState } from 'react'
import './App.css'

function App() {

  /*const [items, setItems] = useState([{id:0, name:"sanket", lastname:"nayak"}, {id:1, name:"esteban", lastname:"nayak"},
                                      {id:1, name:"aylin", lastname:"nayak"}, {id:1, name:"isabeñ", lastname:"nayak"}
                                    ]);*/

  //2 arguments: 1st function, 2nd dependency
  /*useEffect(()=>{

    setInterval(()=>{
      const a= new Date().toLocaleTimeString();
      setTimes(a); 
    }, 1000)
  }, [times])*/

  const [data, setData] = useState([]);
  const url = "https://jsonplaceholder.typicode.com/users";

  const fetchInfo= () => {
    return fetch(url)
      .then((res)=>res.json())
      .then((d)=>console.log(setData(d)))
      .catch((err)=>console.log({error:error.message}))
  }

  useEffect(()=>{
    fetchInfo();
  }, [])

  return (
    <>
      <h1>List of Students</h1>

      {
        data.map((e)=>{
          return (<>
        
            <h2>{e.username}</h2>
            <h3>{e.email}</h3>
          </>)
        })
      }
    </>
  )
}

export default App
